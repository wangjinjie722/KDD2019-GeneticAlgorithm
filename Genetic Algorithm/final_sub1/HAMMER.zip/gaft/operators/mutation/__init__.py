
''' Package for built-in mutation operators '''

from .flip_bit_mutation import FlipBitMutation, FlipBitBigMutation

